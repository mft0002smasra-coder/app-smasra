/* ============================================================
   APP SMASRA — konfigurasi & logik kongsi (dipakai semua muka)
   ============================================================ */

const SCHOOL_LOGO_URL = "https://lh3.googleusercontent.com/d/1JFlMpX8nCN4ZKW9SRiNdtFT-UC8D3nlN";

// Link app AppSheet eRKS (perlukan sign-in staf sendiri — dibuka dalam tab baru)
const APPSHEET_ERKS_URL = "https://www.appsheet.com/start/210829a8-31c7-4ade-ba58-fcd8cf73c305";

// GANTI dengan URL Web App selepas awak deploy Code.gs (Deploy > New deployment > Web app)
const API_URL = "https://script.google.com/macros/s/AKfycbxNMX-PHWy4t8PdQhj-jekw9T8V7b1lN2M8sQ9d8jybfeSLvKS9jB8XuKbjjYRwshcz/exec";
const SPREADSHEET_ID = "1EohV_hfuS6SDgiqDn--QQiM_y92_K4jvGyh87nA3HOo";

/**
 * Fungsi berpusat untuk baca Sheet TERUS guna gviz (BUKAN lalui Apps Script)
 * — jauh lebih laju, elak "cold start"/overhead pelaksanaan skrip. Guna ni
 * untuk SEMUA bacaan data (bukan tulis) merentasi seluruh app.
 * Pulangkan: { cols: [nama lajur ternormal...], rows: [{c:[...]}...] }
 */
async function gvizFetch(spreadsheetId, sheetName) {
  const url = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/gviz/tq?tqx=out:json&sheet=${encodeURIComponent(sheetName)}&headers=1&_ts=${Date.now()}`;
  const res = await fetch(url, { cache: "no-store" });
  const text = await res.text();
  const jsonStr = text.substring(text.indexOf("{"), text.lastIndexOf("}") + 1);
  const table = JSON.parse(jsonStr).table;
  const cols = (table.cols || []).map((c) => String(c.label || "").trim().toUpperCase());
  return { cols, rows: table.rows || [] };
}
/** Ambil nilai sel ikut nama lajur (bukan kedudukan) dari satu baris gviz */
function gvizCell(row, cols, colName) {
  const idx = cols.indexOf(colName.toUpperCase());
  if (idx === -1) return "";
  const c = (row.c || [])[idx];
  return c && c.v != null ? c.v : "";
}

/** Tarikh HARI INI ikut zon waktu tempatan (BUKAN UTC) — elak bug lama
 * "new Date().toISOString()" yang boleh tersasar 1 hari hampir tengah malam. */
function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// GANTI dengan OAuth Client ID dari Google Cloud Console untuk aktifkan "Sign in with Google"
const GOOGLE_CLIENT_ID = "702368440468-u7uoc6396frmum2j0mllbc3llqi4tgbn.apps.googleusercontent.com";

const USER_KEY = "smasra_user";

/* ---------------- Ikon SVG (garis nipis, seragam) ---------------- */

const ICONS = {
  home: '<path d="M4 11.5L12 4l8 7.5"/><path d="M6 10v9a1 1 0 0 0 1 1h3v-6h4v6h3a1 1 0 0 0 1-1v-9"/>',
  profile: '<circle cx="12" cy="8" r="3.2"/><path d="M6 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/>',
  announce: '<path d="M3 10v4a1 1 0 0 0 1 1h2l5 3V6L6 9H4a1 1 0 0 0-1 1z"/><path d="M15 8.3a4 4 0 0 1 0 7.4"/><path d="M18 5.7a7.5 7.5 0 0 1 0 12.6"/>',
  calendar: '<rect x="3.5" y="5" width="17" height="16" rx="2"/><path d="M3.5 9.5h17"/><path d="M8 3v4M16 3v4"/><path d="M9 14.3l2 2 4-4.1"/>',
  folder: '<path d="M3.5 7.5a1.5 1.5 0 0 1 1.5-1.5h3.6l2 2H19a1.5 1.5 0 0 1 1.5 1.5v8.5A1.5 1.5 0 0 1 19 19.5H5A1.5 1.5 0 0 1 3.5 18z"/>',
  chart: '<path d="M4.5 20V10.5"/><path d="M10 20V4"/><path d="M15.5 20v-7"/><path d="M21 20H3"/>',
  graduate: '<path d="M12 4l9 4.5-9 4.5-9-4.5z"/><path d="M6.5 11v4.2c0 1 2.4 2.3 5.5 2.3s5.5-1.3 5.5-2.3V11"/><path d="M21 8.5v5"/>',
  external: '<path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5"/>',
  event: '<rect x="3.5" y="5" width="17" height="16" rx="2"/><path d="M3.5 9.5h17"/><path d="M8 3v4M16 3v4"/><circle cx="12" cy="14.5" r="2.2" fill="currentColor" stroke="none"/>',
  clipboard: '<path d="M9 4.5h6a1 1 0 0 1 1 1V6h-8v-.5a1 1 0 0 1 1-1z"/><rect x="5" y="6" width="14" height="15" rx="2"/><path d="M8.5 11.5h7M8.5 15h7M8.5 18h4.5"/>',
  door: '<rect x="5" y="3" width="14" height="18" rx="1.5"/><circle cx="14" cy="12" r="1.1" fill="currentColor" stroke="none"/><path d="M3 21h18"/>',
  heart: '<path d="M12 20s-7-4.5-9.5-9C.8 7.5 2.5 4 6 4c2 0 3.5 1.2 4 2.5.5-1.3 2-2.5 4-2.5 3.5 0 5.2 3.5 3.5 7-2.5 4.5-9.5 9-9.5 9z"/>',
  trophy: '<path d="M7 4h10v4a5 5 0 0 1-10 0V4z"/><path d="M7 5H4a3 3 0 0 0 3 4"/><path d="M17 5h3a3 3 0 0 1-3 4"/><path d="M12 13v3"/><path d="M8 20h8"/><path d="M9 20a3 3 0 0 1 6 0"/>',
  back: '<path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/>',
  power: '<path d="M12 3.5v8"/><path d="M6.7 6.7a8 8 0 1 0 10.6 0"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
};

function iconSvg(name) {
  return `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;
}

function renderIcons() {
  document.querySelectorAll("[data-icon]").forEach((el) => {
    el.innerHTML = iconSvg(el.getAttribute("data-icon"));
  });
}

/* ---------------- Session ---------------- */

function getSavedUser() {
  try {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}
function saveUser(user) { localStorage.setItem(USER_KEY, JSON.stringify(user)); }
function logout() { localStorage.removeItem(USER_KEY); location.href = "index.html"; }
function apiConfigured() { return API_URL && API_URL.indexOf("PASTE_") !== 0; }
function googleConfigured() { return GOOGLE_CLIENT_ID && GOOGLE_CLIENT_ID.indexOf("PASTE_") !== 0; }

/**
 * POST ke Apps Script yang TAHAN quirk platform Google: kadang-kadang
 * (terutama bila skrip padat/lambat) Google pulangkan HALAMAN HTML dalaman
 * (bukan JSON dari jsonResponse() kita) WALAUPUN operasi (tulis ke Sheet)
 * SEBENARNYA berjaya — sebab tu "data masuk tapi ralat JSON di app".
 * Baca respons sebagai TEKS dahulu, cuba parse JSON; kalau gagal TAPI
 * status HTTP okay, anggap ia berjaya (fallback), bukan terus lempar ralat.
 */
async function postToAppsScript(url, payload) {
  const res = await fetch(url, { method: "POST", body: JSON.stringify(payload) });
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch (e) {
    if (res.ok) return { success: true, _fallbackParse: true };
    throw new Error("Respons pelayan tidak sah (bukan JSON).");
  }
}

function showLoginError(msg) {
  const el = document.getElementById("login-error");
  if (!el) return;
  el.textContent = msg;
  el.classList.remove("hidden");
}

/* ---------------- Login (kongsi oleh borang emel & Google) ---------------- */

async function loginWithEmail(email, btn, btnLabel) {
  if (!apiConfigured()) {
    showLoginError("Sistem belum disambungkan ke Apps Script (API_URL belum diisi).");
    return;
  }
  if (btn) { btn.disabled = true; btn.textContent = "Mengesahkan..."; }
  try {
    const res = await fetch(`${API_URL}?action=getUser&email=${encodeURIComponent(email)}`);
    const data = await res.json();
    if (data.found) {
      saveUser({
        email, nama: data.nama, jawatan: data.jawatan, gambar: data.gambar, role: data.role || "",
        role2: data.role2 || "", role3: data.role3 || "", telefon: data.telefon || "", emel1: data.emel1 || email, emel2: data.emel2 || "",
      });
      location.reload();
    } else {
      showLoginError("Emel tidak berdaftar dalam sistem. Hubungi admin sekolah.");
      if (btn) { btn.disabled = false; btn.textContent = btnLabel; }
    }
  } catch (err) {
    showLoginError("Ralat sambungan ke server. Cuba lagi.");
    if (btn) { btn.disabled = false; btn.textContent = btnLabel; }
  }
}

function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  if (!email) { showLoginError("Sila masukkan emel awak."); return; }
  const btn = document.getElementById("login-btn");
  loginWithEmail(email, btn, "Log Masuk");
}

function decodeJwt(token) {
  try {
    const base64 = token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    const json = decodeURIComponent(
      atob(base64).split("").map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2)).join("")
    );
    return JSON.parse(json);
  } catch (e) { return null; }
}

function handleGoogleCredential(response) {
  const payload = decodeJwt(response.credential);
  if (!payload || !payload.email) { showLoginError("Gagal baca akaun Google."); return; }
  loginWithEmail(payload.email, null, "");
}

function initGoogleSignIn() {
  if (!googleConfigured() || !window.google || !window.google.accounts) return;
  const container = document.getElementById("google-btn-container");
  if (!container) return;
  try {
    google.accounts.id.initialize({ client_id: GOOGLE_CLIENT_ID, callback: handleGoogleCredential });
    google.accounts.id.renderButton(container, { theme: "filled_black", size: "large", shape: "pill", text: "signin_with", width: 260 });
  } catch (e) { /* domain belum dibenarkan / GSI belum sedia */ }
}

/* ---------------- Header hero / Drawer / Bottom nav / Jam ---------------- */

function toggleDrawer() {
  document.getElementById("drawer").classList.toggle("open");
  document.getElementById("drawer-overlay").classList.toggle("open");
}
function closeDrawer() {
  document.getElementById("drawer").classList.remove("open");
  document.getElementById("drawer-overlay").classList.remove("open");
}

function updateClock() {
  const el = document.getElementById("live-clock");
  if (!el) return;
  const now = new Date();
  let h = now.getHours();
  const m = String(now.getMinutes()).padStart(2, "0");
  const s = String(now.getSeconds()).padStart(2, "0");
  const suffix = h < 12 ? "PG" : "PTG";
  h = h % 12; if (h === 0) h = 12;
  el.textContent = `${String(h).padStart(2, "0")}:${m}:${s} ${suffix}`;
}

function renderHeader(user) {
  document.querySelectorAll(".school-logo-img").forEach((img) => { img.src = SCHOOL_LOGO_URL; });
  document.querySelectorAll(".user-avatar-img").forEach((img) => {
    img.src = user.gambar || SCHOOL_LOGO_URL;
    img.onerror = function () { this.onerror = null; this.src = SCHOOL_LOGO_URL; };
  });
  const greet = document.getElementById("header-greet-name");
  if (greet) greet.textContent = user.nama || user.email;
  updateClock();
  setInterval(updateClock, 1000);
}

/**
 * Dipanggil oleh setiap halaman untuk semak login & papar skrin yang betul.
 * onReady(user) dipanggil sekali user sah log masuk.
 */
/* ---------------- Splash Screen (sekali setiap sesi, index.html sahaja) ---------------- */
function initSplashScreen() {
  const splash = document.getElementById("splash-screen");
  if (!splash) return;

  if (sessionStorage.getItem("smasra_splash_shown")) {
    splash.remove();
    return;
  }
  sessionStorage.setItem("smasra_splash_shown", "1");

  const dustBox = document.getElementById("splash-dust");
  const cx = window.innerWidth / 2;
  const cy = window.innerHeight / 2 - 30;
  for (let i = 0; i < 42; i++) {
    const span = document.createElement("span");
    const angle = Math.random() * Math.PI * 2;
    const dist = 50 + Math.random() * 150;
    span.style.left = cx + "px";
    span.style.top = cy + "px";
    span.style.setProperty("--dx", Math.cos(angle) * dist + "px");
    span.style.setProperty("--dy", Math.sin(angle) * dist + "px");
    span.style.animationDelay = (0.25 + Math.random() * 1.6) + "s";
    dustBox.appendChild(span);
  }

  setTimeout(() => {
    splash.classList.add("hide");
    setTimeout(() => splash.remove(), 750);
  }, 3300);
}

/* ============================================================
   STRUKTUR MENU BERPUSAT — 5 Parent Menu (Pengurusan/Kurikulum/
   Pengurusan T6/HEM/KOKU), dipakai bersama oleh sidebar (semua muka)
   dan Menu Utama Home (drill-down).
   ============================================================ */
const MENU_STRUCTURE = [
  {
    key: "pengurusan", label: "Pengurusan", icon: "folder",
    children: [
      { href: "pengumuman.html", icon: "announce", label: "Hebahan" },
      { href: "laporan-pentadbir.html", icon: "clipboard", label: "Laporan Pentadbir" },
      { href: "laporan-guru-bertugas.html", icon: "folder", label: "Laporan Guru Bertugas" },
      { href: "permohonan-cuti.html", icon: "clipboard", label: "Permohonan Cuti Rehat" },
      { href: "kewangan.html", icon: "chart", label: "Kewangan" },
      { href: "kehadiran-staf.html", icon: "calendar", label: "Kehadiran Staf" },
      { href: "event.html", icon: "event", label: "Event" },
    ],
  },
  {
    key: "kurikulum", label: "Kurikulum", icon: "graduate",
    children: [
      { href: "tempahan-bilik.html", icon: "door", label: "Tempahan Bilik Khas" },
      { href: "jadual-guru.html", icon: "clipboard", label: "Jadual Guru" },
      { href: "jadual-guru-ganti.html", icon: "clipboard", label: "Jadual Guru Ganti" },
      { href: "erph-analisis.html", icon: "chart", label: "Analisis e-RPH" },
    ],
  },
  {
    key: "t6", label: "Pengurusan T6", icon: "chart",
    children: [
      { href: null, icon: "chart", label: "Akan Datang", soon: true },
    ],
  },
  {
    key: "hem", label: "HEM", icon: "heart",
    children: [
      { href: "kehadiran-murid.html", icon: "graduate", label: "Kehadiran Murid" },
      { href: "tempahan-kaunseling.html", icon: "heart", label: "Tempahan Kaunseling" },
      { href: "data-murid.html", icon: "chart", label: "Data Murid" },
      { href: "keberadaan-murid.html", icon: "clipboard", label: "Keberadaan Murid" },
    ],
  },
  {
    key: "koku", label: "KOKU", icon: "trophy",
    children: [
      { href: null, icon: "trophy", label: "Akan Datang", soon: true },
    ],
  },
];

/* ---------------- Sidebar (drawer) — accordion 5 Parent Menu ---------------- */
function renderDrawerMenu() {
  const box = document.getElementById("drawer-menu-body");
  if (!box) return;
  const currentPage = location.pathname.split("/").pop();

  const ntActive = currentPage === "notifikasi.html" ? " active" : "";
  const notifItem = `<a class="drawer-item${ntActive}" href="notifikasi.html"><span data-icon="bell"></span><span class="drawer-label">Notifikasi</span><span class="nt-drawer-badge hidden" id="nt-drawer-badge"></span></a>`;

  box.innerHTML = notifItem + MENU_STRUCTURE.map((group) => {
    const hasActive = group.children.some((c) => c.href === currentPage);
    const childrenHtml = group.children.map((c) => {
      if (!c.href || c.soon) {
        return `<div class="drawer-item drawer-sub soon"><span data-icon="${c.icon}"></span><span class="drawer-label">${c.label}</span></div>`;
      }
      const active = c.href === currentPage ? " active" : "";
      return `<a class="drawer-item drawer-sub${active}" href="${c.href}"><span data-icon="${c.icon}"></span><span class="drawer-label">${c.label}</span></a>`;
    }).join("");
    return `<div class="drawer-group">
      <button class="drawer-parent${hasActive ? " active" : ""}" onclick="toggleDrawerGroup('${group.key}')">
        <span data-icon="${group.icon}"></span><span class="drawer-label">${group.label}</span>
        <span class="drawer-chevron">&#9662;</span>
      </button>
      <div class="drawer-children${hasActive ? " open" : ""}" id="drawer-group-${group.key}">${childrenHtml}</div>
    </div>`;
  }).join("");

  renderIcons();
}
function toggleDrawerGroup(key) {
  const el = document.getElementById(`drawer-group-${key}`);
  const btn = el.previousElementSibling;
  const isOpen = el.classList.contains("open");
  document.querySelectorAll(".drawer-children").forEach((d) => d.classList.remove("open"));
  document.querySelectorAll(".drawer-parent").forEach((b) => b.classList.remove("expanded"));
  if (!isOpen) { el.classList.add("open"); btn.classList.add("expanded"); }
}

/* ---------------- Home: Menu Utama drill-down ---------------- */
function renderHomeMenu(groupKey) {
  const grid = document.getElementById("home-module-grid");
  if (!grid) return;

  if (!groupKey) {
    grid.innerHTML = MENU_STRUCTURE.map((g) =>
      `<div class="module-tile" onclick="renderHomeMenu('${g.key}')"><span data-icon="${g.icon}"></span><span class="module-tile-label">${g.label}</span></div>`
    ).join("") + `<a class="module-tile" href="kehadiran-staf.html"><span data-icon="calendar"></span><span class="module-tile-label">Kehadiran Staf</span></a>`;
    renderIcons();
    return;
  }

  const group = MENU_STRUCTURE.find((g) => g.key === groupKey);
  const backTileHtml = `<div class="module-tile module-back" onclick="renderHomeMenu(null)"><span data-icon="back"></span><span class="module-tile-label">Kembali</span></div>`;
  const tileHtml = (c) => {
    if (!c.href || c.soon) return `<div class="module-tile soon"><span data-icon="${c.icon}"></span><span class="module-tile-label">${c.label}</span></div>`;
    return `<a class="module-tile" href="${c.href}"><span data-icon="${c.icon}"></span><span class="module-tile-label">${c.label}</span></a>`;
  };

  const CHUNK = 6; // 2 baris x 3 lajur setiap muka
  const allTilesHtml = [backTileHtml, ...group.children.map(tileHtml)];
  if (allTilesHtml.length <= 6) {
    grid.innerHTML = allTilesHtml.join("");
  } else {
    // >6 ubin (termasuk Kembali) — pecah ke beberapa muka, boleh slide kiri/kanan.
    // "Kembali" jadi ubin PERTAMA muka 1 — sebaris sama dengan ikon-ikon lain.
    const pages = [];
    for (let i = 0; i < allTilesHtml.length; i += CHUNK) pages.push(allTilesHtml.slice(i, i + CHUNK));
    grid.innerHTML = `
      <div class="module-pager-outer">
        <div class="module-pager-track" id="module-pager-track">
          ${pages.map((page) => `<div class="module-pager-page"><div class="module-grid module-grid-inner">${page.join("")}</div></div>`).join("")}
        </div>
      </div>`;
    setTimeout(initModuleMenuPager, 0);
  }
  renderIcons();
}

/* ---------------- Paginasi ikon menu (>5 ikon dalam satu kumpulan) ---------------- */
let moduleMenuPagerIndex = 0;
function initModuleMenuPager() {
  const track = document.getElementById("module-pager-track");
  if (!track) return;
  const count = track.children.length;
  moduleMenuPagerIndex = 0;

  let startX = 0, dragging = false;
  track.addEventListener("touchstart", (e) => { startX = e.touches[0].clientX; dragging = true; track.style.transition = "none"; }, { passive: true });
  track.addEventListener("touchmove", (e) => {
    if (!dragging) return;
    const deltaX = e.touches[0].clientX - startX;
    track.style.transform = `translateX(calc(-${moduleMenuPagerIndex * 100}% + ${deltaX}px))`;
  }, { passive: true });
  track.addEventListener("touchend", (e) => {
    if (!dragging) return;
    dragging = false;
    track.style.transition = "";
    const deltaX = e.changedTouches[0].clientX - startX;
    if (deltaX < -40 && moduleMenuPagerIndex < count - 1) moduleMenuPagerGoTo(moduleMenuPagerIndex + 1);
    else if (deltaX > 40 && moduleMenuPagerIndex > 0) moduleMenuPagerGoTo(moduleMenuPagerIndex - 1);
    else moduleMenuPagerGoTo(moduleMenuPagerIndex);
  });
}
function moduleMenuPagerGoTo(idx) {
  const track = document.getElementById("module-pager-track");
  if (!track) return;
  moduleMenuPagerIndex = idx;
  track.style.transform = `translateX(-${idx * 100}%)`;
}

/* ---------------- Home: swipe antara kad (Rekod Kehadiran <-> Jadual Waktu) ---------------- */
let homeSwipeIndex = 0;
let homeSwipeStartX = 0;
let homeSwipeDeltaX = 0;
let homeSwipeDragging = false;

function homeSwipePageCount() {
  const track = document.getElementById("home-swipe-track");
  return track ? track.children.length : 1;
}
function homeSwipeGoTo(idx) {
  const count = homeSwipePageCount();
  homeSwipeIndex = Math.max(0, Math.min(idx, count - 1));
  const track = document.getElementById("home-swipe-track");
  if (track) track.style.transform = `translateX(-${homeSwipeIndex * (100 / count)}%)`;
}

function initHomeSwipe() {
  const track = document.getElementById("home-swipe-track");
  if (!track || track.dataset.swipeBound) return;
  track.dataset.swipeBound = "1";
  const count = homeSwipePageCount();

  // Tetapkan lebar track/page SECARA DINAMIK ikut bilangan kad SEBENAR
  // (sesetengah kad — cth Keberadaan Murid — mungkin dibuang kalau tiada data).
  track.style.width = `${count * 100}%`;
  document.querySelectorAll(".home-swipe-page").forEach((p) => { p.style.width = `${100 / count}%`; });

  track.addEventListener("touchstart", (e) => {
    homeSwipeStartX = e.touches[0].clientX;
    homeSwipeDragging = true;
    track.style.transition = "none";
  }, { passive: true });

  track.addEventListener("touchmove", (e) => {
    if (!homeSwipeDragging) return;
    homeSwipeDeltaX = e.touches[0].clientX - homeSwipeStartX;
    const basePercent = -homeSwipeIndex * (100 / count);
    const dragPercent = (homeSwipeDeltaX / track.offsetWidth) * (100 / count);
    track.style.transform = `translateX(${basePercent + dragPercent}%)`;
  }, { passive: true });

  track.addEventListener("touchend", () => {
    homeSwipeDragging = false;
    track.style.transition = "";
    const threshold = 50;
    if (homeSwipeDeltaX < -threshold && homeSwipeIndex < count - 1) homeSwipeIndex++;
    else if (homeSwipeDeltaX > threshold && homeSwipeIndex > 0) homeSwipeIndex--;
    homeSwipeDeltaX = 0;
    homeSwipeGoTo(homeSwipeIndex);
  });
}

/* ================= Tetapan Akses Modul (dinamik, boleh ubah admin) ================= */
// Sheet "TetapanAkses" dalam Spreadsheet utama — setiap modul (Data Murid,
// Jadual Guru, dll) boleh baca dari sini utk tentukan Jawatan/Role/Role2
// mana yang dibenarkan akses, TANPA perlu edit kod. Nilai LALAI (fallback)
// padan EXACT tingkah laku hardcode asal — kalau fetch gagal/Sheet kosong,
// app kekal berfungsi macam biasa (tiada gangguan).
const ACCESS_SETTINGS_DEFAULTS = {
  data_murid: { jawatan: "PPP (GURU DATA MURID)", role: "Admin", role2: "" },
  jadual_guru: { jawatan: "PPP (GURU JADUAL WAKTU)", role: "", role2: "Pentadbir" },
  kaunseling: { jawatan: "PPP (KAUNSELOR SEPENUH MASA)", role: "Admin", role2: "Pentadbir" },
  laporan_pentadbir: { jawatan: "", role: "", role2: "Pentadbir" },
};
let ACCESS_SETTINGS = { ...ACCESS_SETTINGS_DEFAULTS };

async function fetchAccessSettings() {
  try {
    const url = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:json&sheet=${encodeURIComponent("TetapanAkses")}&headers=1&_ts=${Date.now()}`;
    const res = await fetch(url, { cache: "no-store" });
    const text = await res.text();
    const jsonStr = text.substring(text.indexOf("{"), text.lastIndexOf("}") + 1);
    const table = JSON.parse(jsonStr).table;
    const fetched = {};
    (table.rows || []).forEach((r) => {
      const c = r.c || [];
      const get = (i) => (c[i] && c[i].v != null ? String(c[i].v).trim() : "");
      const key = get(0);
      if (key) fetched[key] = { jawatan: get(2), role: get(3), role2: get(4) };
    });
    // GABUNG dengan default — kalau modul tertentu tiada dalam Sheet (belum sync), guna default
    ACCESS_SETTINGS = { ...ACCESS_SETTINGS_DEFAULTS, ...fetched };
  } catch (e) {
    ACCESS_SETTINGS = { ...ACCESS_SETTINGS_DEFAULTS }; // fetch gagal — kekal default, app tetap jalan
  }
}

/** Semak akses SATU modul ikut tetapan dinamik + Admin App (Role3) SENTIASA lulus. */
function checkModuleAccess(user, moduleKey) {
  const isAdminApp = String(user.role3 || "").trim().toLowerCase() === "admin app";
  if (isAdminApp) return true;
  const setting = ACCESS_SETTINGS[moduleKey] || ACCESS_SETTINGS_DEFAULTS[moduleKey] || {};
  const jawatanUpper = String(user.jawatan || "").trim().toUpperCase();
  const matchJawatan = setting.jawatan && jawatanUpper === setting.jawatan.trim().toUpperCase();
  const matchRole = setting.role && String(user.role || "").trim().toLowerCase() === setting.role.trim().toLowerCase();
  const matchRole2 = setting.role2 && String(user.role2 || "").trim().toLowerCase() === setting.role2.trim().toLowerCase();
  return !!(matchJawatan || matchRole || matchRole2);
}

/** Muat modul Notifikasi (loceng, badge, pop-up urgent) selepas log masuk — tidak menyekat halaman. */
function ntBoot(user) {
  try {
    if (typeof ntInit === "function") { ntInit(user); return; }
    const sc = document.createElement("script");
    sc.src = "notifikasi.js?v=20261016b";
    sc.onload = () => { try { ntInit(user); } catch (e) { /* abaikan */ } };
    document.head.appendChild(sc);
  } catch (e) { /* notifikasi tidak kritikal */ }
}

async function initApp(onReady) {
  renderIcons();
  document.querySelectorAll(".school-logo-img").forEach((img) => { img.src = SCHOOL_LOGO_URL; });

  const user = getSavedUser();
  const loginScreen = document.getElementById("login-screen");
  const appContent = document.getElementById("app-content");

  if (!user) {
    loginScreen.classList.remove("hidden");
    appContent.classList.add("hidden");
    const form = document.getElementById("login-form");
    if (form) form.addEventListener("submit", handleLogin);
    initGoogleSignIn();
    if (googleConfigured()) {
      const t = setInterval(() => {
        if (window.google && window.google.accounts) { initGoogleSignIn(); clearInterval(t); }
      }, 300);
      setTimeout(() => clearInterval(t), 5000);
    }
  } else {
    loginScreen.classList.add("hidden");
    appContent.classList.remove("hidden");
    renderHeader(user);
    renderDrawerMenu();
    ntBoot(user);
    await fetchAccessSettings(); // sedia SEBELUM onReady, supaya modul boleh guna checkModuleAccess() terus
    if (typeof onReady === "function") onReady(user);
    refreshUserInBackground(user);
  }
}

/**
 * Selepas render pantas guna data cache (localStorage), semak SEMULA di
 * latar belakang terhadap Sheet sebenar — kalau jawatan/role/role2/nama
 * berubah (cth. Admin kemaskini terus dalam DatabaseSTAFF), reload sekali
 * supaya semua kebenaran & paparan betul, tanpa perlu log keluar manual.
 */
async function refreshUserInBackground(cachedUser) {
  if (!apiConfigured()) return;
  try {
    const res = await fetch(`${API_URL}?action=getUser&email=${encodeURIComponent(cachedUser.email)}`);
    const data = await res.json();
    if (!data || !data.found) return;
    const changed = data.jawatan !== cachedUser.jawatan || data.role !== cachedUser.role || data.role2 !== cachedUser.role2 || data.role3 !== cachedUser.role3 || data.nama !== cachedUser.nama;
    if (changed) {
      saveUser({
        email: cachedUser.email, nama: data.nama, jawatan: data.jawatan, gambar: data.gambar,
        role: data.role || "", role2: data.role2 || "", role3: data.role3 || "", telefon: data.telefon, emel1: data.emel1, emel2: data.emel2,
      });
      location.reload();
    }
  } catch (e) { /* tak kritikal — cuba lagi bila page seterusnya dimuat */ }
}

/* ---------------- Pengumuman (dikongsi index.html & pengumuman.html) ---------------- */

function escapeHtml(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function escapeAttr(str) { return String(str).replace(/"/g, "&quot;"); }

function renderAnnounceCard(item) {
  const img = item.gambar
    ? `<img class="announce-img" src="${escapeAttr(item.gambar)}" alt="Gambar pengumuman" loading="lazy" onerror="this.style.display='none'" onclick="openImageLightbox('${escapeAttr(item.gambar)}')">`
    : "";
  return `<div class="glass announce-card">${img}<div class="announce-body"><div class="announce-text">${escapeHtml(item.teks || "")}</div></div></div>`;
}

/* ---------------- Lightbox gambar (klik untuk lihat penuh) ---------------- */
function openImageLightbox(url) {
  let box = document.getElementById("img-lightbox");
  if (!box) {
    box = document.createElement("div");
    box.id = "img-lightbox";
    box.className = "img-lightbox";
    box.onclick = closeImageLightbox;
    box.innerHTML = `<img id="img-lightbox-img" alt="Gambar penuh"><button class="img-lightbox-close" onclick="closeImageLightbox()">✕</button>`;
    document.body.appendChild(box);
  }
  document.getElementById("img-lightbox-img").src = url;
  box.classList.add("show");
}
function closeImageLightbox() {
  const box = document.getElementById("img-lightbox");
  if (box) box.classList.remove("show");
}

async function fetchPengumumanItems() {
  const { rows } = await gvizFetch(SPREADSHEET_ID, "Pengumuman");
  const todayKey = todayIso();
  const gvizDateToIso = (v) => {
    if (!v) return "";
    const m = String(v).match(/Date\((\d+),(\d+),(\d+)/);
    if (!m) return String(v).slice(0, 10);
    const y = parseInt(m[1]), mo = parseInt(m[2]) + 1, d = parseInt(m[3]);
    return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  };
  // Lajur ikut KEDUDUKAN tetap (sama macam Code.gs asal): A=Gambar, B=Teks, C=TarikhTamat
  let items = rows.map((r) => {
    const c = r.c || [];
    const gambar = (c[0] && c[0].v) || "";
    const teks = (c[1] && c[1].v) || "";
    const tarikhTamat = gvizDateToIso((c[2] && c[2].v) || "");
    return { gambar, teks, tarikhTamat };
  }).filter((it) => (it.gambar || it.teks) && (!it.tarikhTamat || it.tarikhTamat >= todayKey));
  items.reverse(); // terbaru dahulu
  return items;
}

async function loadPengumumanList(targetId) {
  const listEl = document.getElementById(targetId);
  if (!listEl) return;
  try {
    const items = await fetchPengumumanItems();
    if (!items.length) {
      listEl.innerHTML = '<div class="empty-state">Belum ada pengumuman lagi.</div>';
      return;
    }
    listEl.innerHTML = items.map(renderAnnounceCard).join("");
  } catch (err) {
    listEl.innerHTML = '<div class="empty-state">Gagal muatkan pengumuman. Cuba lagi.</div>';
  }
}

/* ---------------- Kad Home: Hebahan Terkini (swipe ke-3, auto-scroll jika >1) ---------------- */
let homeHebahanItems = [];
let homeHebahanIndex = 0;
let homeHebahanTimer = null;

async function renderHomeHebahanCard() {
  const box = document.getElementById("home-hebahan-content");
  if (!box) return;
  box.innerHTML = `<div class="empty-state" style="padding:14px 2px;font-size:11px">Memuatkan...</div>`;
  clearInterval(homeHebahanTimer);
  try {
    homeHebahanItems = await fetchPengumumanItems();
    if (!homeHebahanItems.length) {
      box.innerHTML = `<div class="empty-state" style="padding:14px 2px;font-size:11px">Belum ada pengumuman lagi.</div>`;
      return;
    }
    homeHebahanIndex = 0;
    homeHebahanShowCurrent();
    if (homeHebahanItems.length > 1) {
      homeHebahanTimer = setInterval(() => {
        homeHebahanIndex = (homeHebahanIndex + 1) % homeHebahanItems.length;
        homeHebahanShowCurrent();
      }, 5000);
    }
  } catch (err) {
    box.innerHTML = `<div class="empty-state" style="padding:14px 2px;font-size:11px">Gagal muatkan pengumuman.</div>`;
  }
}

function homeHebahanShowCurrent() {
  const box = document.getElementById("home-hebahan-content");
  if (!box || !homeHebahanItems.length) return;
  const item = homeHebahanItems[homeHebahanIndex];
  let html = "";
  if (item.gambar) {
    html += `<div class="home-hebahan-img-wrap"><img class="home-hebahan-img" src="${escapeAttr(item.gambar)}" alt="Gambar pengumuman" onerror="this.parentElement.style.display='none'" onclick="openImageLightbox('${escapeAttr(item.gambar)}')"></div>`;
  }
  if (item.teks) {
    html += `<div class="home-hebahan-text">${escapeHtml(item.teks)}</div>`;
  }
  box.innerHTML = html;
}

/* ---------------- Banner carousel (index.html sahaja) ---------------- */

let bannerImages = [];
let bannerIndex = 0;
let bannerTimer = null;

async function loadBanner() {
  const track = document.getElementById("banner-track");
  if (!track) return;
  try {
    const { rows } = await gvizFetch(SPREADSHEET_ID, "Banner");
    bannerImages = rows.map((r) => (r.c[0] && r.c[0].v) || "").filter(Boolean);
    if (!bannerImages || bannerImages.length === 0) {
      track.innerHTML = '<div class="banner-empty">Belum ada banner. Tambah link gambar di tab "Banner", lajur A.</div>';
      return;
    }
    track.innerHTML = bannerImages
      .map((url) => `<div class="banner-slide"><img src="${escapeAttr(url)}" alt="Banner sekolah" loading="lazy" onerror="this.parentElement.style.display='none'"></div>`)
      .join("");
    bannerIndex = 0;
    if (bannerImages.length > 1) {
      bannerTimer = setInterval(() => goToBanner((bannerIndex + 1) % bannerImages.length), 5000);
    }
  } catch (err) {
    track.innerHTML = '<div class="banner-empty">Gagal muatkan banner.</div>';
  }
}

function goToBanner(i) {
  bannerIndex = i;
  const track = document.getElementById("banner-track");
  if (track) track.style.transform = `translateX(-${i * 100}%)`;
}

function expandBanner() {
  if (!bannerImages.length) return;
  document.getElementById("lightbox-img").src = bannerImages[bannerIndex];
  document.getElementById("lightbox-overlay").classList.remove("hidden");
}
function closeLightbox() { document.getElementById("lightbox-overlay").classList.add("hidden"); }

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("service-worker.js").catch(() => {});
  });
}
